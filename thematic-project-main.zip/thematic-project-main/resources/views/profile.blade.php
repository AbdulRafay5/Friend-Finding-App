<x-app-layout>
	<livewire:profile.profile-page :user="$user" />
</x-app-layout>