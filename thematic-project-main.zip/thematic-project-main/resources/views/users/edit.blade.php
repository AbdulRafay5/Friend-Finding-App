<x-app-layout>
	<livewire:users.edit :user="$user" />
</x-app-layout>