# Privacy Policy (Totally Serious™)

**Effective Date:** April 17, 2025

Welcome to our not-so-shady social media platform. Here's how we *definitely* handle your privacy:

---

## 1. We Collect Everything 📦
Yes, *everything*. Your name, your cat's name, what you had for lunch, and your browser history from 2008. Don't worry — we don't even know what half of it means.

## 2. We Use Cookies 🍪
Not the chocolate chip kind. These cookies follow you around like a clingy ex. They help us "improve your experience" (and by that we mean show you ads you didn’t ask for).

## 3. Selling Your Data 💰
Oh yes, we're totally selling your data... to aliens. Or was it advertisers? We forget. But hey — thanks for the free content!

## 4. Sharing With Third Parties 🕵️
We may or may not share your data with:
- Our “partners” (aka anyone who offers us money)
- Marketing ninjas
- The office goldfish (he’s very curious)

## 5. Security 🔒
We use industry-standard security. That means we Googled “how to secure a website” and followed the top 3 steps. Should be fine.

## 6. Children’s Privacy 👶
If you're under 13, go outside and play. This site isn't for you. Unless you're a coding prodigy. Then... call us?

## 7. Updates 📜
We might change this policy whenever we feel like it. If we do, we won’t tell you, but just pretend you read it again and clicked "Accept."

---

Thanks for trusting us (lol). Questions? Complaints? Praise? Send memes to **privacy@definitelynotasketchysite.com**
